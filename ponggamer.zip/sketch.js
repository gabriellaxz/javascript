posx = 200
posy = 200
dx = 5;
dy = 3;
ponte=0;
pontd=0;
meuretposy=0;
post=0;

var raio = 20, posx=200, posy=200, velX = 2
var coeR= 255, corG = 0, corB = 0
function setup() {
  createCanvas(400, 400);
 
}

function draw() {
  background(63, 143, 143);
  textSize(30);
  textFont('fontBold');
  fill(255, 255, 255);
  text('X', 174, 100);
  fill('purple');
  rect(100,22,170,28)
  fill(200, 255, 255);
  text('PLACAR', 130, 45);
  textFont('century-gothic');
  
  
  
  fill(color(0, 0, 255));
  
  text(ponte, 280,100);
  
   fill("red");
  text(pontd, 85, 100);

 posx += dx;
 posy += dy;
 
  circle(posx,posy,raio*2);
  fill('red')
  rect(10,mouseY,10,80);
  
  circle(posx,posy,raio*2);
  fill(color(0, 0, 255));
  
  rect(380,mouseY,10,80);
  post=mouseY;
  if(posx > 200){
    rect(380,post,10,80);
  }
  
 //CHECANDO SE A BOLA BATEU NO RECT VERMELHO DIREITO
  if ((posx>=width-40 && mouseY + 80 < posy) || (posx>=width-40 && posy + 20 < mouseY) ) {
     pontd++;

   }

  //CHECANDO SE A BOLA BATEU NO RECT VERMELHO ESQUERDO
  if ((posx == 30 && mouseY + 80 < posy) || (posx == 30 && posy + 30 < mouseY) ) {
     ponte++;

   }
  
  
  if (posx>=width-40 || posx == 30 )
   {
    dx = -dx;

   }
  if (posy>=height-30 || posy==20)
   {
    dy = -dy
   
  }
}